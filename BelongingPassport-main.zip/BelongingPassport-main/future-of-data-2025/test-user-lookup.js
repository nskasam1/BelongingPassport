// Test script for user lookup functionality
// Run with: node test-user-lookup.js

const API_BASE_URL = 'http://localhost:3000/api';

async function testUserLookup() {
  console.log('🧪 Testing User Lookup API...\n');

  // Test email - replace with a real email from your VolunteerMatters system
  const testEmail = 'test@example.com';

  try {
    // Test 1: Basic lookup
    console.log('1️⃣ Testing basic user lookup...');
    const basicResponse = await fetch(`${API_BASE_URL}/lookup-user?email=${encodeURIComponent(testEmail)}`);
    const basicResult = await basicResponse.json();
    
    if (basicResult.success) {
      console.log('✅ Basic lookup successful!');
      console.log('   User found:', basicResult.data.profile ? 'Yes' : 'No');
      if (basicResult.data.profile) {
        console.log('   Name:', `${basicResult.data.profile.firstName} ${basicResult.data.profile.lastName}`);
        console.log('   Email:', basicResult.data.profile.email);
        console.log('   Branch:', basicResult.data.profile.branchName || 'N/A');
        console.log('   Total Hours:', basicResult.data.profile.totalHours);
      }
    } else {
      console.log('❌ Basic lookup failed:', basicResult.error);
    }

    console.log('\n2️⃣ Testing lookup with history...');
    
    // Test 2: Lookup with history
    const historyResponse = await fetch(`${API_BASE_URL}/lookup-user`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        email: testEmail, 
        includeHistory: true 
      }),
    });
    
    const historyResult = await historyResponse.json();
    
    if (historyResult.success) {
      console.log('✅ Lookup with history successful!');
      console.log('   User found:', historyResult.data.profile ? 'Yes' : 'No');
      if (historyResult.data.profile) {
        console.log('   Name:', `${historyResult.data.profile.firstName} ${historyResult.data.profile.lastName}`);
        console.log('   History entries:', historyResult.data.history ? historyResult.data.history.length : 0);
      }
    } else {
      console.log('❌ Lookup with history failed:', historyResult.error);
    }

    console.log('\n3️⃣ Testing multiple email lookup...');
    
    // Test 3: Multiple emails
    const multipleEmails = [testEmail, 'another@example.com', 'third@example.com'];
    const multipleResponse = await fetch(`${API_BASE_URL}/lookup-user?emails=${multipleEmails.join(',')}`);
    const multipleResult = await multipleResponse.json();
    
    if (multipleResult.success) {
      console.log('✅ Multiple email lookup successful!');
      console.log(`   Found ${multipleResult.data.found} profiles out of ${multipleResult.data.total} emails`);
    } else {
      console.log('❌ Multiple email lookup failed:', multipleResult.error);
    }

  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
  }
}

// Run the test
testUserLookup();
