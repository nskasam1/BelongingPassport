// Test script for branch sync functionality
// Run with: node test-branch-sync.js

const API_BASE_URL = 'http://localhost:3000/api';

async function testBranchSync() {
  console.log('🧪 Testing Branch Sync API...\n');

  try {
    // Test 1: Dry run to see what branches are available
    console.log('1️⃣ Testing dry run...');
    const dryRunResponse = await fetch(`${API_BASE_URL}/sync-branches`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ dryRun: true }),
    });

    const dryRunResult = await dryRunResponse.json();
    
    if (dryRunResult.success) {
      console.log('✅ Dry run successful!');
      console.log(`   Found ${dryRunResult.data.branchesFound} branches in API`);
      console.log('   Sample branches:', dryRunResult.data.branches.slice(0, 3));
    } else {
      console.log('❌ Dry run failed:', dryRunResult.error);
      return;
    }

    console.log('\n2️⃣ Testing actual sync...');
    
    // Test 2: Actual sync
    const syncResponse = await fetch(`${API_BASE_URL}/sync-branches`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ force: true }),
    });

    const syncResult = await syncResponse.json();
    
    if (syncResult.success) {
      console.log('✅ Sync successful!');
      console.log(`   Synced ${syncResult.data.branchesSynced} branches to Firestore`);
    } else {
      console.log('❌ Sync failed:', syncResult.error);
    }

    console.log('\n3️⃣ Testing branch retrieval...');
    
    // Test 3: Get branches from Firestore
    const getResponse = await fetch(`${API_BASE_URL}/sync-branches`);
    const getResult = await getResponse.json();
    
    if (getResult.success) {
      console.log('✅ Branch retrieval successful!');
      console.log(`   Found ${getResult.data.branchesCount} branches in Firestore`);
      console.log('   Sample branches:', getResult.data.branches.slice(0, 3));
    } else {
      console.log('❌ Branch retrieval failed:', getResult.error);
    }

  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
  }
}

// Run the test
testBranchSync();
