// VolunteerMatters API Types

export interface VolunteerMattersVolunteer {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  branchId?: string;
  branchName?: string;
  totalHours: number;
  lastActivity?: string;
  status: 'active' | 'inactive' | 'pending';
}

export interface VolunteerMattersAssignment {
  id: string;
  volunteerId: string;
  projectId: string;
  projectName: string;
  branchId: string;
  branchName: string;
  date: string;
  hours: number;
  status: 'completed' | 'pending' | 'cancelled';
  description?: string;
}

export interface VolunteerMattersProject {
  id: string;
  name: string;
  description?: string;
  branchId: string;
  branchName: string;
  startDate: string;
  endDate?: string;
  status: 'active' | 'completed' | 'cancelled';
  totalVolunteers: number;
  totalHours: number;
}

export interface VolunteerMattersBranch {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  totalVolunteers: number;
  totalHours: number;
}

export interface VolunteerLeaderboardEntry {
  volunteerId: string;
  firstName: string;
  lastName: string;
  totalHours: number;
  rank: number;
  badge?: string;
}

export interface VolunteerBadge {
  id: string;
  name: string;
  description: string;
  icon: string;
  hoursRequired: number;
  earned: boolean;
  earnedDate?: string;
}

export interface BranchVolunteerStats {
  branchId: string;
  branchName: string;
  totalVolunteers: number;
  activeVolunteers: number;
  totalHours: number;
  averageHoursPerVolunteer: number;
  topVolunteers: VolunteerLeaderboardEntry[];
}

export interface VolunteerMattersApiResponse<T> {
  success: boolean;
  data: T;
  error?: string;
  timestamp: string;
}
