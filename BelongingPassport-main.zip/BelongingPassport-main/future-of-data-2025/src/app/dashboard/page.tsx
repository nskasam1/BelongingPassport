'use client';

import React, { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/SimpleAuthContext';
import { AdminDashboard } from '@/components/dashboard/AdminDashboard';
import { StaffDashboard } from '@/components/dashboard/StaffDashboard';
import { VolunteerDashboard } from '@/components/dashboard/VolunteerDashboard';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { NextApiResponse } from 'next';


export default function DashboardPage() {
  const { user, userProfile, loading } = useAuth();
  const router = useRouter();

  const fetchData = async (endpoint: string): Promise<any> => {
    const response = await fetch(`/api/data?endpoint=${encodeURIComponent(endpoint)}`);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const result: NextApiResponse = await response.json();
    console.log(result);
    
  
    
    return response.json();
  };


  // Redirect to auth page if user is not authenticated
  useEffect(() => {
    if (!loading && !user) {
      router.push('/auth');
    }
  }, [user, loading, router]);
  useEffect(() => {
   
    fetchData("/volunteerHistory");

}, []);
 

  const renderDashboard = () => {
    if (!userProfile) return null;

    switch (userProfile.role) {
      case 'primary_admin':
        return <AdminDashboard />;
      case 'staff':
        return <StaffDashboard />;
      case 'volunteer':
        return <VolunteerDashboard />;
      default:
        return (
          <div className="min-h-screen flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Unknown Role</h1>
              <p className="text-gray-600">Your role is not recognized.</p>
            </div>
          </div>
        );
    }
  };

  // Show loading spinner while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  // Don't render dashboard if user is not authenticated
  if (!user) {
    return null;
  }

  return (
    <ProtectedRoute>
      {renderDashboard()}
    </ProtectedRoute>
  );
}
