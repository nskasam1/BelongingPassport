'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/SimpleAuthContext';
import { UserProfile, UserRole } from '@/types/auth';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';

export default function AdminPortalPage() {
  const { userProfile, signOut } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [showPromoteModal, setShowPromoteModal] = useState(false);

  // Sample data - in a real app, this would come from Firestore
  useEffect(() => {
    // Simulate loading users
    setTimeout(() => {
      setUsers([
        {
          uid: '1',
          email: 'john.doe@ymca.org',
          displayName: 'John Doe',
          role: 'staff',
          branchId: 'downtown',
          branchName: 'Downtown YMCA',
          createdAt: new Date('2024-01-15'),
          updatedAt: new Date('2024-01-15'),
        },
        {
          uid: '2',
          email: 'jane.smith@ymca.org',
          displayName: 'Jane Smith',
          role: 'volunteer',
          createdAt: new Date('2024-02-20'),
          updatedAt: new Date('2024-02-20'),
        },
        {
          uid: '3',
          email: 'mike.johnson@ymca.org',
          displayName: 'Mike Johnson',
          role: 'staff',
          branchId: 'northside',
          branchName: 'Northside YMCA',
          createdAt: new Date('2024-03-10'),
          updatedAt: new Date('2024-03-10'),
        },
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const handlePromoteUser = (user: UserProfile) => {
    setSelectedUser(user);
    setShowPromoteModal(true);
  };

  const handlePromoteToAdmin = async () => {
    if (!selectedUser) return;
    
    // In a real app, this would update the user in Firestore
    console.log('Promoting user to admin:', selectedUser.email);
    setShowPromoteModal(false);
    setSelectedUser(null);
  };

  const handlePromoteToStaff = async () => {
    if (!selectedUser) return;
    
    // In a real app, this would update the user in Firestore
    console.log('Promoting user to staff:', selectedUser.email);
    setShowPromoteModal(false);
    setSelectedUser(null);
  };

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-ymca-red"></div>
      </div>
    );
  }

  return (
    <ProtectedRoute allowedRoles={['primary_admin']}>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
        {/* Navigation */}
        <nav className="bg-white shadow-lg border-b-4 border-ymca-red">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-20">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">Y</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-ymca-blue">
                    Admin Portal
                  </h1>
                  <p className="text-sm text-ymca-gray">User Management</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="text-right">
                  <p className="text-sm text-ymca-gray">Welcome back,</p>
                  <p className="font-semibold text-ymca-dark-gray">{userProfile?.displayName}</p>
                </div>
                <span className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-ymca-red text-white shadow-lg">
                  ⚡ PRIMARY ADMIN
                </span>
                <button
                  onClick={handleSignOut}
                  className="btn-ymca-outline"
                >
                  Sign Out
                </button>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-ymca-blue mb-2">
              Admin Portal
            </h2>
            <p className="text-ymca-gray">
              Manage users, sync data, and oversee all YMCA Future of Data operations.
            </p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <div className="card-ymca">
              <h3 className="text-lg font-bold text-ymca-blue mb-4">
                User Management
              </h3>
              <p className="text-sm text-ymca-gray mb-4">
                Manage user roles, promote staff members, and oversee all users.
              </p>
              <div className="text-sm text-ymca-blue">
                Currently viewing user management
              </div>
            </div>

            <div className="card-ymca">
              <h3 className="text-lg font-bold text-ymca-blue mb-4">
                Branch Sync
              </h3>
              <p className="text-sm text-ymca-gray mb-4">
                Sync branches from VolunteerMatters API to Firestore database.
              </p>
              <a
                href="/admin-portal/sync-branches"
                className="btn-ymca-primary text-sm"
              >
                Manage Branches
              </a>
            </div>

            <div className="card-ymca">
              <h3 className="text-lg font-bold text-ymca-blue mb-4">
                User Lookup
              </h3>
              <p className="text-sm text-ymca-gray mb-4">
                Find user profiles in VolunteerMatters by email address.
              </p>
              <a
                href="/admin-portal/lookup-user"
                className="btn-ymca-outline text-sm"
              >
                Lookup Users
              </a>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="card-ymca">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center mr-4">
                  <span className="text-white font-bold text-lg">👥</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-ymca-gray">Total Users</p>
                  <p className="text-2xl font-bold text-ymca-blue">{users.length}</p>
                </div>
              </div>
            </div>

            <div className="card-ymca">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mr-4">
                  <span className="text-white font-bold text-lg">👨‍💼</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-ymca-gray">Staff Members</p>
                  <p className="text-2xl font-bold text-ymca-blue">
                    {users.filter(u => u.role === 'staff').length}
                  </p>
                </div>
              </div>
            </div>

            <div className="card-ymca">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mr-4">
                  <span className="text-white font-bold text-lg">🤝</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-ymca-gray">Volunteers</p>
                  <p className="text-2xl font-bold text-ymca-blue">
                    {users.filter(u => u.role === 'volunteer').length}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Users Table */}
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              All Users
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-semibold text-ymca-dark-gray">Name</th>
                    <th className="text-left py-3 px-4 font-semibold text-ymca-dark-gray">Email</th>
                    <th className="text-left py-3 px-4 font-semibold text-ymca-dark-gray">Role</th>
                    <th className="text-left py-3 px-4 font-semibold text-ymca-dark-gray">Branch</th>
                    <th className="text-left py-3 px-4 font-semibold text-ymca-dark-gray">Joined</th>
                    <th className="text-left py-3 px-4 font-semibold text-ymca-dark-gray">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.uid} className="border-b border-gray-100 hover:bg-ymca-light-gray">
                      <td className="py-3 px-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-ymca-gradient rounded-full flex items-center justify-center mr-3">
                            <span className="text-white font-bold text-sm">
                              {user.displayName.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          {user.displayName}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-ymca-gray">{user.email}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          user.role === 'primary_admin' 
                            ? 'bg-red-100 text-red-800'
                            : user.role === 'staff'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-green-100 text-green-800'
                        }`}>
                          {user.role.replace('_', ' ').toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-ymca-gray">
                        {user.branchName || 'N/A'}
                      </td>
                      <td className="py-3 px-4 text-ymca-gray">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">
                        {user.role !== 'primary_admin' && (
                          <button
                            onClick={() => handlePromoteUser(user)}
                            className="btn-ymca-primary text-sm px-3 py-1"
                          >
                            Promote
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Promote Modal */}
        {showPromoteModal && selectedUser && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
              <h3 className="text-xl font-bold text-ymca-blue mb-4">
                Promote User
              </h3>
              <p className="text-ymca-gray mb-6">
                Promote <strong>{selectedUser.displayName}</strong> to a higher role:
              </p>
              <div className="space-y-3">
                {selectedUser.role === 'volunteer' && (
                  <button
                    onClick={handlePromoteToStaff}
                    className="w-full btn-ymca-primary text-left"
                  >
                    👥 Promote to Staff
                  </button>
                )}
                <button
                  onClick={handlePromoteToAdmin}
                  className="w-full btn-ymca-secondary text-left"
                >
                  ⚡ Promote to Primary Admin
                </button>
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  onClick={() => setShowPromoteModal(false)}
                  className="btn-ymca-outline"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
