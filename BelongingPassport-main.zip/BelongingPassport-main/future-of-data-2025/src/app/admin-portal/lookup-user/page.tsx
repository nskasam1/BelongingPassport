'use client';

import React, { useState } from 'react';
import { useAuth } from '@/contexts/SimpleAuthContext';
import { useRouter } from 'next/navigation';

interface UserProfile {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  branchId?: string;
  branchName?: string;
  totalHours: number;
  status: string;
}

export default function LookupUserPage() {
  const { userProfile, loading: authLoading } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');

  // Redirect if not admin
  if (!authLoading && userProfile?.role !== 'primary_admin') {
    router.push('/dashboard');
    return null;
  }

  const handleLookup = async () => {
    if (!email.trim()) {
      setError('Please enter an email address');
      return;
    }

    setLoading(true);
    setError('');
    setResult(null);

    try {
      const response = await fetch(`/api/lookup-user?email=${encodeURIComponent(email)}`);
      const data = await response.json();

      if (data.success) {
        setResult(data.data);
      } else {
        setError(data.error || 'Lookup failed');
      }
    } catch (err) {
      setError('Failed to lookup user');
    } finally {
      setLoading(false);
    }
  };

  const handleLookupWithHistory = async () => {
    if (!email.trim()) {
      setError('Please enter an email address');
      return;
    }

    setLoading(true);
    setError('');
    setResult(null);

    try {
      const response = await fetch('/api/lookup-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email, 
          includeHistory: true 
        }),
      });
      
      const data = await response.json();

      if (data.success) {
        setResult(data.data);
      } else {
        setError(data.error || 'Lookup failed');
      }
    } catch (err) {
      setError('Failed to lookup user');
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-ymca-red">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">Y</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-ymca-blue">
                  User Lookup
                </h1>
                <p className="text-sm text-ymca-gray">Find users in VolunteerMatters by email</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <button
                onClick={() => router.push('/admin-portal')}
                className="btn-ymca-outline"
              >
                Back to Admin
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Lookup Form */}
        <div className="card-ymca mb-8">
          <h2 className="text-xl font-bold text-ymca-blue mb-6">
            Lookup User Profile
          </h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-ymca-dark-gray mb-2">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="user@example.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-ymca-blue focus:border-transparent"
              />
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={handleLookup}
                disabled={loading}
                className="btn-ymca-primary"
              >
                {loading ? 'Looking up...' : 'Lookup Profile'}
              </button>
              
              <button
                onClick={handleLookupWithHistory}
                disabled={loading}
                className="btn-ymca-secondary"
              >
                {loading ? 'Looking up...' : 'Lookup with History'}
              </button>
            </div>
            
            {error && (
              <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                {error}
              </div>
            )}
          </div>
        </div>

        {/* Results */}
        {result && (
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              Lookup Results
            </h3>
            
            {result.profile ? (
              <div className="space-y-6">
                {/* Contact Information */}
                {result.contact && (
                  <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                    <h4 className="text-lg font-semibold text-ymca-blue mb-4">
                      Contact Information (from VolunteerMatters)
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-ymca-gray">Contact ID</p>
                        <p className="font-medium text-ymca-dark-gray">
                          {result.contact.id || result.contact.contactId || 'N/A'}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-ymca-gray">Email</p>
                        <p className="font-medium text-ymca-dark-gray">{result.contact.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-ymca-gray">Phone</p>
                        <p className="font-medium text-ymca-dark-gray">
                          {result.contact.phone || result.contact.phoneNumber || 'N/A'}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-ymca-gray">Branch</p>
                        <p className="font-medium text-ymca-dark-gray">
                          {result.contact.branchName || result.contact.branch_name || 'N/A'}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Profile Information */}
                <div className="bg-ymca-light-gray p-6 rounded-lg">
                  <h4 className="text-lg font-semibold text-ymca-dark-gray mb-4">
                    Enhanced Profile (with Volunteer History)
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-ymca-gray">Name</p>
                      <p className="font-medium text-ymca-dark-gray">
                        {result.profile.firstName} {result.profile.lastName}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-ymca-gray">Email</p>
                      <p className="font-medium text-ymca-dark-gray">{result.profile.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-ymca-gray">Phone</p>
                      <p className="font-medium text-ymca-dark-gray">
                        {result.profile.phone || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-ymca-gray">Status</p>
                      <p className="font-medium text-ymca-dark-gray capitalize">
                        {result.profile.status}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-ymca-gray">Branch</p>
                      <p className="font-medium text-ymca-dark-gray">
                        {result.profile.branchName || 'N/A'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-ymca-gray">Total Hours</p>
                      <p className="font-medium text-ymca-dark-gray">
                        {result.profile.totalHours || 0}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Volunteer History */}
                {result.history && result.history.length > 0 && (
                  <div>
                    <h4 className="text-lg font-semibold text-ymca-dark-gray mb-4">
                      Volunteer History ({result.history.length} activities)
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Date
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Project
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Hours
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {result.history.slice(0, 10).map((assignment: any, index: number) => (
                            <tr key={index} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {new Date(assignment.date).toLocaleDateString()}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {assignment.projectName || 'N/A'}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {assignment.hours}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                  assignment.status === 'completed' 
                                    ? 'bg-green-100 text-green-800'
                                    : 'bg-yellow-100 text-yellow-800'
                                }`}>
                                  {assignment.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-ymca-gray">No profile found for this email address</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
