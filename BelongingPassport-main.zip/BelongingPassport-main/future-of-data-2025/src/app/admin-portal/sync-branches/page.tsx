'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/SimpleAuthContext';
import { useRouter } from 'next/navigation';

interface Branch {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  totalVolunteers: number;
  totalHours: number;
  createdAt: string;
}

export default function SyncBranchesPage() {
  const { userProfile, loading: authLoading } = useAuth();
  const router = useRouter();
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // Redirect if not admin
  useEffect(() => {
    if (!authLoading && userProfile?.role !== 'primary_admin') {
      router.push('/dashboard');
    }
  }, [userProfile, authLoading, router]);

  // Load existing branches on component mount
  useEffect(() => {
    loadExistingBranches();
  }, []);

  const loadExistingBranches = async () => {
    try {
      const response = await fetch('/api/sync-branches');
      const result = await response.json();
      
      if (result.success) {
        setBranches(result.data.branches || []);
      } else {
        setError(result.error || 'Failed to load branches');
      }
    } catch (err) {
      setError('Failed to load existing branches');
    }
  };

  const syncBranches = async (force = false) => {
    setLoading(true);
    setError('');
    setMessage('');

    try {
      const response = await fetch('/api/sync-branches', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ force }),
      });

      const result = await response.json();

      if (result.success) {
        setMessage(result.message);
        // Reload branches after successful sync
        await loadExistingBranches();
      } else {
        setError(result.error || 'Failed to sync branches');
      }
    } catch (err) {
      setError('Failed to sync branches');
    } finally {
      setLoading(false);
    }
  };

  const dryRun = async () => {
    setLoading(true);
    setError('');
    setMessage('');

    try {
      const response = await fetch('/api/sync-branches', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ dryRun: true }),
      });

      const result = await response.json();

      if (result.success) {
        setMessage(`Dry run completed: Found ${result.data.branchesFound} branches in API`);
        console.log('API branches:', result.data.branches);
      } else {
        setError(result.error || 'Dry run failed');
      }
    } catch (err) {
      setError('Dry run failed');
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (userProfile?.role !== 'primary_admin') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-ymca-red">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">Y</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-ymca-blue">
                  Branch Sync
                </h1>
                <p className="text-sm text-ymca-gray">Sync branches from VolunteerMatters API</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <button
                onClick={() => router.push('/admin-portal')}
                className="btn-ymca-outline"
              >
                Back to Admin
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Action Buttons */}
        <div className="mb-8">
          <div className="card-ymca">
            <h2 className="text-xl font-bold text-ymca-blue mb-6">
              Branch Synchronization
            </h2>
            
            <div className="space-y-4">
              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => dryRun()}
                  disabled={loading}
                  className="btn-ymca-outline"
                >
                  {loading ? 'Running...' : 'Dry Run (Preview)'}
                </button>
                
                <button
                  onClick={() => syncBranches(false)}
                  disabled={loading}
                  className="btn-ymca-primary"
                >
                  {loading ? 'Syncing...' : 'Sync Branches'}
                </button>
                
                <button
                  onClick={() => syncBranches(true)}
                  disabled={loading}
                  className="btn-ymca-secondary"
                >
                  {loading ? 'Force Syncing...' : 'Force Sync (Overwrite)'}
                </button>
                
                <button
                  onClick={loadExistingBranches}
                  disabled={loading}
                  className="btn-ymca-outline"
                >
                  Refresh List
                </button>
              </div>
              
              {message && (
                <div className="p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                  {message}
                </div>
              )}
              
              {error && (
                <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                  {error}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Branches List */}
        <div className="card-ymca">
          <h3 className="text-xl font-bold text-ymca-blue mb-6">
            Branches in Firestore ({branches.length})
          </h3>
          
          {branches.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-ymca-gray">No branches found in Firestore</p>
              <p className="text-sm text-ymca-gray mt-2">
                Click "Sync Branches" to load branches from the VolunteerMatters API
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Address
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Contact
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Volunteers
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Hours
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Added
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {branches.map((branch) => (
                    <tr key={branch.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {branch.name}
                        </div>
                        <div className="text-sm text-gray-500">
                          ID: {branch.id}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {branch.address || 'N/A'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {branch.phone || 'N/A'}
                        </div>
                        <div className="text-sm text-gray-500">
                          {branch.email || 'N/A'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {branch.totalVolunteers}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {branch.totalHours}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(branch.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
