'use client';

import React from 'react';
import { useAuth } from '@/contexts/SimpleAuthContext';
import Link from 'next/link';

export default function Home() {
  const { user, userProfile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (user && userProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-red-50">
        {/* Navigation */}
        <nav className="bg-white shadow-lg border-b-4 border-ymca-red">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-20">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">Y</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-ymca-blue">
                    YMCA Future of Data
                  </h1>
                  <p className="text-sm text-ymca-gray">2025 Conference</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="text-right">
                  <p className="text-sm text-ymca-gray">Welcome back,</p>
                  <p className="font-semibold text-ymca-dark-gray">{userProfile.displayName}</p>
                </div>
                <span className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-ymca-red text-white shadow-lg">
                  {userProfile.role.replace('_', ' ').toUpperCase()}
                </span>
                {userProfile.role === 'primary_admin' && (
                  <Link
                    href="/admin-portal"
                    className="btn-ymca-secondary"
                  >
                    Admin Portal
                  </Link>
                )}
                <Link
                  href="/dashboard"
                  className="btn-ymca-primary"
                >
                  Go to Dashboard
                </Link>
              </div>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-ymca-blue mb-6">
              Welcome to YMCA Future of Data 2025
            </h1>
            <p className="text-xl text-ymca-gray mb-8 max-w-3xl mx-auto">
              Your role-based authentication system is working perfectly! 
              Access your personalized dashboard and start making a difference in your community.
            </p>
          </div>

          {/* Account Info Card */}
          <div className="max-w-2xl mx-auto">
            <div className="card-ymca">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-ymca-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-2xl">
                    {userProfile.displayName.charAt(0).toUpperCase()}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-ymca-blue mb-2">
                  {userProfile.displayName}
                </h2>
                <p className="text-ymca-gray">{userProfile.email}</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="text-center p-4 bg-ymca-light-gray rounded-lg">
                  <p className="text-sm text-ymca-gray">Role</p>
                  <p className="font-semibold text-ymca-blue">
                    {userProfile.role.replace('_', ' ').toUpperCase()}
                  </p>
                </div>
                <div className="text-center p-4 bg-ymca-light-gray rounded-lg">
                  <p className="text-sm text-ymca-gray">Status</p>
                  <p className="font-semibold text-green-600">Active</p>
                </div>
                <div className="text-center p-4 bg-ymca-light-gray rounded-lg">
                  <p className="text-sm text-ymca-gray">Member Since</p>
                  <p className="font-semibold text-ymca-blue">
                    {new Date(userProfile.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div className="flex justify-center space-x-4">
                <Link
                  href="/dashboard"
                  className="btn-ymca-primary flex-1 text-center"
                >
                  Access Dashboard
                </Link>
                <button className="btn-ymca-outline flex-1">
                  Update Profile
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-ymca-red">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">Y</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-ymca-blue">
                  YMCA Future of Data
                </h1>
                <p className="text-sm text-ymca-gray">2025 Conference</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Link
                href="/auth"
                className="btn-ymca-primary"
              >
                Sign In
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold text-ymca-blue mb-6">
            YMCA Future of Data 2025
          </h1>
          <p className="text-2xl text-ymca-gray mb-8 max-w-4xl mx-auto">
            Empowering communities through data-driven insights and collaborative innovation. 
            Join us in shaping the future of data science and community impact.
          </p>
          <div className="flex justify-center space-x-6">
            <Link
              href="/auth"
              className="btn-ymca-primary text-lg px-8 py-4"
            >
              Get Started
            </Link>
            <button className="btn-ymca-outline text-lg px-8 py-4">
              Learn More
            </button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="card-ymca text-center">
            <div className="w-16 h-16 bg-ymca-gradient rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-white font-bold text-2xl">👥</span>
            </div>
            <h3 className="text-xl font-bold text-ymca-blue mb-3">Role-Based Access</h3>
            <p className="text-ymca-gray">
              Three distinct user roles: Primary Admin, Staff, and Volunteers with tailored access and capabilities.
            </p>
          </div>

          <div className="card-ymca text-center">
            <div className="w-16 h-16 bg-ymca-gradient rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-white font-bold text-2xl">🔐</span>
            </div>
            <h3 className="text-xl font-bold text-ymca-blue mb-3">Secure Authentication</h3>
            <p className="text-ymca-gray">
              Enterprise-grade security powered by Firebase with encrypted data transmission and secure sessions.
            </p>
          </div>

          <div className="card-ymca text-center">
            <div className="w-16 h-16 bg-ymca-gradient rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-white font-bold text-2xl">📊</span>
            </div>
            <h3 className="text-xl font-bold text-ymca-blue mb-3">Data Dashboard</h3>
            <p className="text-ymca-gray">
              Personalized dashboards with real-time insights and community impact metrics for each role.
            </p>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-ymca-gradient rounded-2xl p-12 text-center text-white">
          <h2 className="text-4xl font-bold mb-6">Ready to Make a Difference?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join the YMCA Future of Data 2025 community and start contributing to meaningful change today.
          </p>
          <Link
            href="/auth"
            className="bg-white text-ymca-blue hover:bg-gray-100 font-bold py-4 px-8 rounded-lg text-lg transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            Join Now
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-ymca-dark-gray text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-4 mb-6">
              <div className="w-10 h-10 bg-ymca-gradient rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">Y</span>
              </div>
              <h3 className="text-2xl font-bold">YMCA Future of Data</h3>
            </div>
            <p className="text-gray-300 mb-4">
              Building stronger communities through data-driven insights and collaborative innovation.
            </p>
            <p className="text-sm text-gray-400">
              © 2025 YMCA Future of Data. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
