import { NextResponse } from 'next/server';
import { collection, doc, setDoc, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';

// Function to fetch branches from VolunteerMatters API
async function fetchBranchesFromAPI() {
  const apiKey = process.env.VOLUNTEERMATTERS_API_KEY;
  const apiSecret = process.env.VOLUNTEERMATTERS_API_SECRET;
  const customerCode = process.env.VOLUNTEERMATTERS_CUSTOMER_CODE;

  if (!apiKey || !apiSecret || !customerCode) {
    throw new Error('Missing required environment variables: VOLUNTEERMATTERS_API_KEY, VOLUNTEERMATTERS_API_SECRET, or VOLUNTEERMATTERS_CUSTOMER_CODE');
  }
  
  const credentials = btoa(`${apiKey}:${apiSecret}`);
  
  const url = 'https://api.volunteermatters.io/api/v2/branches';
  
  console.log('=== Fetching Branches from VolunteerMatters API ===');
  console.log('URL:', url);
  
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'X-VM-Customer-Code': customerCode,
        'Accept': 'application/json',
        'User-Agent': 'NextJS-VolunteerMatters/1.0'
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    console.log('Branches fetched successfully:', data);
    return data;
    
  } catch (error) {
    console.error('Error fetching branches:', error);
    throw error;
  }
}

// Function to save branches to Firestore
async function saveBranchesToFirestore(branches: any[]) {
  console.log('=== Saving Branches to Firestore ===');
  
  try {
    const batch = [];
    
    for (const branch of branches) {
      // Create a document reference for each branch
      const branchRef = doc(db, 'branches', branch.id || branch.branchId || `branch_${Date.now()}_${Math.random()}`);
      
      // Prepare branch data for Firestore
      const branchData = {
        id: branch.id || branch.branchId,
        name: branch.name || branch.branchName || 'Unknown Branch',
        address: branch.address || branch.location || '',
        phone: branch.phone || branch.phoneNumber || '',
        email: branch.email || branch.emailAddress || '',
        description: branch.description || '',
        status: branch.status || 'active',
        totalVolunteers: branch.totalVolunteers || branch.volunteerCount || 0,
        totalHours: branch.totalHours || branch.hoursWorked || 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        // Store the original API data for reference
        apiData: branch
      };
      
      batch.push(setDoc(branchRef, branchData));
    }
    
    // Execute all writes in parallel
    await Promise.all(batch);
    
    console.log(`Successfully saved ${branches.length} branches to Firestore`);
    return branches.length;
    
  } catch (error) {
    console.error('Error saving branches to Firestore:', error);
    throw error;
  }
}

// Function to get existing branches from Firestore
async function getExistingBranches() {
  try {
    const branchesRef = collection(db, 'branches');
    const snapshot = await getDocs(branchesRef);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error fetching existing branches:', error);
    return [];
  }
}

// Main API route handler
export async function POST(request: Request) {
  try {
    console.log('=== Starting Branch Sync Process ===');
    
    // Parse request body for options
    const body = await request.json().catch(() => ({}));
    const { force = false, dryRun = false } = body;
    
    // Fetch branches from API
    const apiBranches = await fetchBranchesFromAPI();
    
    if (!Array.isArray(apiBranches)) {
      throw new Error('Invalid API response: expected array of branches');
    }
    
    console.log(`Found ${apiBranches.length} branches in API`);
    
    if (dryRun) {
      return NextResponse.json({
        success: true,
        message: 'Dry run completed',
        data: {
          branchesFound: apiBranches.length,
          branches: apiBranches.map(branch => ({
            id: branch.id || branch.branchId,
            name: branch.name || branch.branchName,
            address: branch.address || branch.location
          }))
        }
      });
    }
    
    // Get existing branches from Firestore
    const existingBranches = await getExistingBranches();
    console.log(`Found ${existingBranches.length} existing branches in Firestore`);
    
    if (!force && existingBranches.length > 0) {
      return NextResponse.json({
        success: false,
        message: 'Branches already exist in Firestore. Use force=true to overwrite.',
        data: {
          existingBranches: existingBranches.length,
          apiBranches: apiBranches.length
        }
      });
    }
    
    // Save branches to Firestore
    const savedCount = await saveBranchesToFirestore(apiBranches);
    
    return NextResponse.json({
      success: true,
      message: `Successfully synced ${savedCount} branches to Firestore`,
      data: {
        branchesSynced: savedCount,
        timestamp: new Date().toISOString()
      }
    });
    
  } catch (error) {
    console.error('Branch sync error:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}

// GET endpoint to check existing branches
export async function GET() {
  try {
    const existingBranches = await getExistingBranches();
    
    return NextResponse.json({
      success: true,
      data: {
        branchesCount: existingBranches.length,
        branches: existingBranches.map(branch => ({
          id: branch.id,
          name: branch.name,
          address: branch.address,
          phone: branch.phone,
          email: branch.email,
          totalVolunteers: branch.totalVolunteers,
          totalHours: branch.totalHours,
          createdAt: branch.createdAt
        }))
      }
    });
    
  } catch (error) {
    console.error('Error fetching existing branches:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      },
      { status: 500 }
    );
  }
}
