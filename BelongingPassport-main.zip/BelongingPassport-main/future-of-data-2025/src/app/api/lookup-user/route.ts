import { NextResponse } from 'next/server';
import { getUserProfileByEmail, getUserProfilesByEmails, searchUserByEmail } from '@/lib/volunteerMattersApi';

// GET endpoint to lookup user profile by email
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');
    const emails = searchParams.get('emails'); // Comma-separated list
    const includeHistory = searchParams.get('includeHistory') === 'true';
    
    if (!email && !emails) {
      return NextResponse.json(
        {
          success: false,
          error: 'Email parameter is required. Use ?email=user@example.com or ?emails=user1@example.com,user2@example.com'
        },
        { status: 400 }
      );
    }
    
    // Handle single email lookup
    if (email) {
      console.log(`Looking up user profile for email: ${email}`);
      
      // First try to search for the contact
      const contactData = await searchUserByEmail(email);
      
      if (!contactData) {
        return NextResponse.json({
          success: false,
          message: 'No contact found for this email address',
          data: { email }
        });
      }
      
      // Get full profile with volunteer history
      const profile = await getUserProfileByEmail(email);
      
      if (!profile) {
        return NextResponse.json({
          success: false,
          message: 'Contact found but could not get full profile',
          data: { 
            email,
            contact: contactData
          }
        });
      }
      
      const result: any = {
        email,
        contact: contactData,
        profile
      };
      
      // Include volunteer history if requested
      if (includeHistory && profile.id) {
        try {
          const { getVolunteerHistory } = await import('@/lib/volunteerMattersApi');
          const history = await getVolunteerHistory(profile.id);
          result.history = history;
        } catch (error) {
          console.warn('Could not fetch volunteer history:', error);
        }
      }
      
      return NextResponse.json({
        success: true,
        message: 'User profile found',
        data: result
      });
    }
    
    // Handle multiple emails lookup
    if (emails) {
      const emailList = emails.split(',').map(e => e.trim()).filter(e => e);
      
      if (emailList.length === 0) {
        return NextResponse.json(
          {
            success: false,
            error: 'No valid emails provided'
          },
          { status: 400 }
        );
      }
      
      console.log(`Looking up user profiles for ${emailList.length} emails`);
      
      const profiles = await getUserProfilesByEmails(emailList);
      
      return NextResponse.json({
        success: true,
        message: `Found ${profiles.length} profiles out of ${emailList.length} emails`,
        data: {
          emails: emailList,
          profiles,
          found: profiles.length,
          total: emailList.length
        }
      });
    }
    
  } catch (error) {
    console.error('User lookup error:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}

// POST endpoint for more complex lookup requests
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { email, emails, includeHistory = false } = body;
    
    if (!email && !emails) {
      return NextResponse.json(
        {
          success: false,
          error: 'Email or emails field is required'
        },
        { status: 400 }
      );
    }
    
    // Handle single email lookup
    if (email) {
      const profile = await getUserProfileByEmail(email);
      
      if (!profile) {
        return NextResponse.json({
          success: false,
          message: 'No profile found for this email address',
          data: { email }
        });
      }
      
      const result: any = {
        email,
        profile
      };
      
      // Include volunteer history if requested
      if (includeHistory && profile.id) {
        try {
          const { getVolunteerHistory } = await import('@/lib/volunteerMattersApi');
          const history = await getVolunteerHistory(profile.id);
          result.history = history;
        } catch (error) {
          console.warn('Could not fetch volunteer history:', error);
        }
      }
      
      return NextResponse.json({
        success: true,
        message: 'User profile found',
        data: result
      });
    }
    
    // Handle multiple emails lookup
    if (emails && Array.isArray(emails)) {
      const profiles = await getUserProfilesByEmails(emails);
      
      return NextResponse.json({
        success: true,
        message: `Found ${profiles.length} profiles out of ${emails.length} emails`,
        data: {
          emails,
          profiles,
          found: profiles.length,
          total: emails.length
        }
      });
    }
    
  } catch (error) {
    console.error('User lookup error:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}
