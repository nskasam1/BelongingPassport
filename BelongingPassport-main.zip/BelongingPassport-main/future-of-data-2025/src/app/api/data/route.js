import { NextResponse } from 'next/server';

async function getVolunteerData(endpoint = '/volunteerHistory') {
  const apiKey = process.env.VOLUNTEERMATTERS_API_KEY;        // Username for Basic Auth
  const apiSecret = process.env.VOLUNTEERMATTERS_API_SECRET;     // Password for Basic Auth
  const customerCode = process.env.VOLUNTEERMATTERS_CUSTOMER_CODE;           // X-VM-Customer-Code header value

  if (!apiKey || !apiSecret || !customerCode) {
    throw new Error('Missing required environment variables: VOLUNTEERMATTERS_API_KEY, VOLUNTEERMATTERS_API_SECRET, or VOLUNTEERMATTERS_CUSTOMER_CODE');
  }
  
  // Create Basic Auth credentials (username:password encoded in base64)
  const credentials = btoa(`${apiKey}:${apiSecret}`);
  
  const url = `https://api.volunteermatters.io/api/v2${endpoint}`;
  
  console.log('=== API Request Details ===');
  console.log('URL:', url);
  console.log('API Key (username):', apiKey);
  console.log('Customer Code:', customerCode);
  console.log('Base64 Credentials:', credentials);
  
 
  try {

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'X-VM-Customer-Code': customerCode,
        'Accept': 'application/json',
        'User-Agent': 'NextJS-VolunteerMatters/1.0'
      }
    });
    
    console.log('=== Response Details ===');
    console.log('Status:', response.status);
    console.log('Status Text:', response.statusText);
    console.log('Headers:', Object.fromEntries(response.headers.entries()));
    
    if (!response.ok) {
      // Get detailed error information
      let errorBody = '';
      const contentType = response.headers.get('content-type');
      
      try {
        if (contentType && contentType.includes('application/json')) {
          const errorJson = await response.json();
          errorBody = JSON.stringify(errorJson, null, 2);
        } else {
          errorBody = await response.text();
        }
      } catch (e) {
        errorBody = 'Could not parse error response';
      }
      
      console.log('Error Response Body:', errorBody);
      
      // Provide specific error messages based on status code
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      
      switch (response.status) {
        case 401:
          errorMessage += ' - Invalid API credentials. Check your API Key and Secret.';
          break;
        case 403:
          errorMessage += ' - Access forbidden. Verify your Customer Code and API permissions.';
          break;
        case 404:
          errorMessage += ' - Endpoint not found. Check the API endpoint path.';
          break;
        case 429:
          errorMessage += ' - Rate limit exceeded. Please wait before making more requests.';
          break;
        case 500:
          errorMessage += ' - Server error. Please try again later.';
          break;
      }
      
      if (errorBody) {
        errorMessage += `\nAPI Response: ${errorBody}`;
      }
      
      throw new Error(errorMessage);
    }
    
    const data = await response.json();
    console.log('=== Success ===');
    console.log('Data received:', typeof data === 'object' ? Object.keys(data) : data);
    
    return data;
    
  } catch (error) {
    console.error('=== API Request Failed ===');
    console.error('Error:', error.message);
    
    if (error.name === 'TypeError' && error.message.includes('fetch')) {
      throw new Error('Network error: Unable to connect to VolunteerMatters API. Check your internet connection.');
    }
    
    throw error;
  }
}

// Test function to validate credentials
async function testCredentials() {
  console.log('=== Testing API Credentials ===');
  
  // Test different common endpoints
  const testEndpoints = ['/branches', '/organizations', '/volunteers'];
  
  for (const endpoint of testEndpoints) {
    try {
      console.log(`Testing endpoint: ${endpoint}`);
      await getVolunteerData(endpoint);
      console.log(`✅ ${endpoint} - Success`);
      return true;
    } catch (error) {
      console.log(`❌ ${endpoint} - Failed:`, error.message);
    }
  }
  
  return false;
}

// Next.js API Route Handler
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const endpoint = searchParams.get('endpoint') || '/volunteerHistory';
    const test = searchParams.get('test') === 'true';
    
    // If test parameter is provided, run credential tests
    if (test) {
      const testResult = await testCredentials();
      return NextResponse.json({
        success: testResult,
        message: testResult ? 'Credentials are valid' : 'Credential test failed - check console logs'
      });
    }
    
    // Validate endpoint to prevent unauthorized access
   
    
    // Fetch data from VolunteerMatters API
    const data = await getVolunteerData(endpoint);
    
    return NextResponse.json({
      success: true,
      data: data,
      endpoint: endpoint
    });
    
  } catch (error) {
    console.error('API Route Error:', error);
    
    return NextResponse.json(
      { 
        success: false, 
        error: error.message || 'Internal server error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}