import { NextResponse } from 'next/server';
import { getAuth } from 'firebase-admin/auth';
import { initializeApp, getApps, cert } from 'firebase-admin/app';

// Initialize Firebase Admin SDK
if (!getApps().length) {
  // You'll need to set these environment variables
  const serviceAccount = {
    type: "service_account",
    project_id: process.env.FIREBASE_PROJECT_ID,
    private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID,
    private_key: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    client_email: process.env.FIREBASE_CLIENT_EMAIL,
    client_id: process.env.FIREBASE_CLIENT_ID,
    auth_uri: "https://accounts.google.com/o/oauth2/auth",
    token_uri: "https://oauth2.googleapis.com/token",
    auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${process.env.FIREBASE_CLIENT_EMAIL}`
  };

  try {
    initializeApp({
      credential: cert(serviceAccount as any),
    });
  } catch (error) {
    console.error('Firebase Admin initialization error:', error);
  }
}

export async function POST(request: Request) {
  try {
    const { email } = await request.json();
    
    if (!email) {
      return NextResponse.json(
        { success: false, error: 'Email is required' },
        { status: 400 }
      );
    }

    console.log(`Attempting to delete user with email: ${email}`);
    
    // Get user by email
    const userRecord = await getAuth().getUserByEmail(email);
    console.log('User found:', userRecord.uid);
    
    // Delete the user
    await getAuth().deleteUser(userRecord.uid);
    console.log('User successfully deleted from Firebase Authentication');
    
    return NextResponse.json({
      success: true,
      message: `User ${email} successfully deleted from Firebase Authentication`,
      data: {
        email,
        uid: userRecord.uid,
        deletedAt: new Date().toISOString()
      }
    });
    
  } catch (error: any) {
    console.error('Error deleting user:', error);
    
    if (error.code === 'auth/user-not-found') {
      return NextResponse.json(
        { 
          success: false, 
          error: 'User not found in Firebase Authentication',
          code: 'USER_NOT_FOUND'
        },
        { status: 404 }
      );
    }
    
    return NextResponse.json(
      { 
        success: false, 
        error: error.message || 'Failed to delete user',
        code: error.code || 'UNKNOWN_ERROR'
      },
      { status: 500 }
    );
  }
}

// GET endpoint to check if user exists
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');
    
    if (!email) {
      return NextResponse.json(
        { success: false, error: 'Email parameter is required' },
        { status: 400 }
      );
    }

    const userRecord = await getAuth().getUserByEmail(email);
    
    return NextResponse.json({
      success: true,
      message: 'User found in Firebase Authentication',
      data: {
        email: userRecord.email,
        uid: userRecord.uid,
        displayName: userRecord.displayName,
        emailVerified: userRecord.emailVerified,
        disabled: userRecord.disabled,
        createdAt: userRecord.metadata.creationTime,
        lastSignIn: userRecord.metadata.lastSignInTime
      }
    });
    
  } catch (error: any) {
    if (error.code === 'auth/user-not-found') {
      return NextResponse.json(
        { 
          success: false, 
          message: 'User not found in Firebase Authentication',
          code: 'USER_NOT_FOUND'
        },
        { status: 404 }
      );
    }
    
    return NextResponse.json(
      { 
        success: false, 
        error: error.message || 'Failed to check user',
        code: error.code || 'UNKNOWN_ERROR'
      },
      { status: 500 }
    );
  }
}
