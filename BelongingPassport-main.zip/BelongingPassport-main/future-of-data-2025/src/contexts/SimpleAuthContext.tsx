'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as firebaseSignOut,
  onAuthStateChanged 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  getDocs 
} from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';
import { AuthContextType, AuthState, UserProfile, UserRole } from '@/types/auth';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AuthState>({
    user: null,
    userProfile: null,
    loading: true,
  });

  // Helper function to get user profile from Firestore
  const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
    try {
      const userDoc = await getDoc(doc(db, 'users', uid));
      if (userDoc.exists()) {
        const data = userDoc.data();
        return {
          uid: data.uid,
          email: data.email,
          displayName: data.displayName,
          role: data.role,
          branchId: data.branchId,
          branchName: data.branchName,
          createdAt: data.createdAt?.toDate() || new Date(),
          updatedAt: data.updatedAt?.toDate() || new Date(),
        };
      }
      return null;
    } catch (error) {
      console.error('Error getting user profile:', error);
      return null;
    }
  };

  // Helper function to enhance user profile with VolunteerMatters data
  const enhanceUserProfileWithVMData = async (userProfile: UserProfile): Promise<UserProfile> => {
    try {
      console.log('Looking up VolunteerMatters profile for:', userProfile.email);
      
      // Call the lookup API endpoint instead of the function directly
      const response = await fetch(`/api/lookup-user?email=${encodeURIComponent(userProfile.email)}`);
      const result = await response.json();
      
      if (result.success && result.data && result.data.profile) {
        const vmProfile = result.data.profile;
        const vmContact = result.data.contact;
        console.log('Found VolunteerMatters profile for:', userProfile.email);
        console.log('VM Profile data:', vmProfile);
        console.log('VM Contact data:', vmContact);
        
        // Extract name from contact data
        const firstName = vmContact?.name?.first || vmProfile.firstName;
        const lastName = vmContact?.name?.last || vmProfile.lastName;
        const displayName = firstName && lastName ? `${firstName} ${lastName}` : userProfile.displayName;
        
        // Extract branch info from contact data
        const branchName = vmContact?.extended?.Primary_Branch || vmProfile.branchName;
        
        // Enhance the user profile with VM data
        const enhancedProfile: UserProfile = {
          ...userProfile,
          displayName,
          branchId: vmProfile.branchId || userProfile.branchId,
          branchName: branchName || userProfile.branchName,
          // Add VM-specific data as additional fields
          vmId: vmProfile.id,
          vmTotalHours: vmProfile.totalHours,
          vmStatus: vmProfile.status,
          vmLastActivity: vmProfile.lastActivity,
          updatedAt: new Date(),
        };
        
        console.log('Enhanced profile:', enhancedProfile);
        console.log('=== PROFILE ENHANCEMENT COMPLETE ===');
        console.log('Final enhanced profile data:', {
          displayName: enhancedProfile.displayName,
          branchName: enhancedProfile.branchName,
          vmId: (enhancedProfile as any).vmId,
          vmTotalHours: (enhancedProfile as any).vmTotalHours,
          vmStatus: (enhancedProfile as any).vmStatus,
          vmLastActivity: (enhancedProfile as any).vmLastActivity
        });
        return enhancedProfile;
      } else {
        console.log('No VolunteerMatters profile found for:', userProfile.email);
        console.log('Lookup result:', result);
        return userProfile;
      }
    } catch (error) {
      console.error('Error enhancing user profile with VM data:', error);
      return userProfile; // Return original profile if enhancement fails
    }
  };

  // Helper function to save user profile to Firestore
  const saveUserProfile = async (userProfile: UserProfile): Promise<void> => {
    try {
      await setDoc(doc(db, 'users', userProfile.uid), {
        uid: userProfile.uid,
        email: userProfile.email,
        displayName: userProfile.displayName,
        role: userProfile.role,
        branchId: userProfile.branchId || null,
        branchName: userProfile.branchName || null,
        vmId: (userProfile as any).vmId || null,
        vmTotalHours: (userProfile as any).vmTotalHours || null,
        vmStatus: (userProfile as any).vmStatus || null,
        vmLastActivity: (userProfile as any).vmLastActivity || null,
        createdAt: userProfile.createdAt,
        updatedAt: userProfile.updatedAt,
      });
    } catch (error) {
      console.error('Error saving user profile:', error);
      throw error;
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      // Load user profile from Firestore
      let userProfile = await getUserProfile(user.uid);
      
      if (!userProfile) {
        // If no profile exists, create a default one
        const defaultProfile: UserProfile = {
          uid: user.uid,
          email: user.email!,
          displayName: user.displayName || 'User',
          role: 'volunteer', // Default role
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        
        // Enhance with VolunteerMatters data
        userProfile = await enhanceUserProfileWithVMData(defaultProfile);
        
        // Save the enhanced profile to Firestore
        await saveUserProfile(userProfile);
        
        setState(prev => ({
          ...prev,
          user,
          userProfile,
          loading: false,
        }));
      } else {
        // Enhance existing profile with latest VM data
        const enhancedProfile = await enhanceUserProfileWithVMData(userProfile);
        
        // Save enhanced profile if it changed
        if (enhancedProfile !== userProfile) {
          await saveUserProfile(enhancedProfile);
        }
        
        setState(prev => ({
          ...prev,
          user,
          userProfile: enhancedProfile,
          loading: false,
        }));
      }
    } catch (error) {
      console.error('Error signing in:', error);
      throw error;
    }
  };

  const signUp = async (email: string, password: string, displayName: string, role: UserRole, branchId?: string, branchName?: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      // Create user profile
      const userProfile: UserProfile = {
        uid: user.uid,
        email: user.email!,
        displayName,
        role,
        branchId,
        branchName,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      
      // Save user profile to Firestore
      await saveUserProfile(userProfile);
      
      setState(prev => ({
        ...prev,
        user,
        userProfile,
        loading: false,
      }));
    } catch (error) {
      console.error('Error signing up:', error);
      throw error;
    }
  };

  const signOut = async () => {
    try {
      await firebaseSignOut(auth);
      setState({
        user: null,
        userProfile: null,
        loading: false,
      });
    } catch (error) {
      console.error('Error signing out:', error);
      throw error;
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!state.user || !state.userProfile) throw new Error('No user logged in');
    
    try {
      const updatedProfile = {
        ...state.userProfile,
        ...updates,
        updatedAt: new Date(),
      };
      
      // Save updated profile to Firestore
      await saveUserProfile(updatedProfile as UserProfile);
      
      setState(prev => ({
        ...prev,
        userProfile: updatedProfile as UserProfile,
      }));
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  };

  useEffect(() => {
    // Set a timeout to prevent infinite loading
    const timeoutId = setTimeout(() => {
      setState(prev => ({ ...prev, loading: false }));
    }, 2000); // 2 second timeout
    
    try {
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        // Clear the timeout since we got a response
        clearTimeout(timeoutId);
        
        if (user) {
          // Load user profile from Firestore
          const userProfile = await getUserProfile(user.uid);
          
          if (userProfile) {
            setState({
              user,
              userProfile,
              loading: false,
            });
          } else {
            // If no profile exists, create a default one
            const defaultProfile: UserProfile = {
              uid: user.uid,
              email: user.email!,
              displayName: user.displayName || 'User',
              role: 'volunteer', // Default role
              createdAt: new Date(),
              updatedAt: new Date(),
            };
            
            // Save the default profile to Firestore
            await saveUserProfile(defaultProfile);
            
            setState({
              user,
              userProfile: defaultProfile,
              loading: false,
            });
          }
        } else {
          setState({
            user: null,
            userProfile: null,
            loading: false,
          });
        }
      });

      return () => {
        clearTimeout(timeoutId);
        unsubscribe();
      };
    } catch (error) {
      console.error('Error setting up auth listener:', error);
      clearTimeout(timeoutId);
      setState(prev => ({ ...prev, loading: false }));
    }
  }, []);

  const value: AuthContextType = {
    user: state.user,
    userProfile: state.userProfile,
    loading: state.loading,
    signIn,
    signUp,
    signOut,
    updateProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
