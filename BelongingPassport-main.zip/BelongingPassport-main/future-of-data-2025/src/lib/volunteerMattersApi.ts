import { 
  VolunteerMattersVolunteer, 
  VolunteerMattersAssignment, 
  VolunteerMattersProject,
  VolunteerMattersBranch,
  VolunteerLeaderboardEntry,
  VolunteerBadge,
  BranchVolunteerStats,
  VolunteerMattersApiResponse 
} from '@/types/volunteerMatters';

const API_BASE_URL = '/api/data';

// Helper function to make API calls
async function fetchVolunteerMattersData<T>(endpoint: string): Promise<T> {
  // Use absolute URL for server-side calls
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
  const url = `${baseUrl}${API_BASE_URL}?endpoint=${encodeURIComponent(endpoint)}`;
  
  const response = await fetch(url);
  
  if (!response.ok) {
    throw new Error(`API request failed: ${response.status} ${response.statusText}`);
  }
  
  const result: VolunteerMattersApiResponse<T> = await response.json();
  
  if (!result.success) {
    throw new Error(result.error || 'API request failed');
  }
  
  return result.data;
}

// Get all volunteers (for staff to see branch volunteers)
export async function getVolunteers(): Promise<VolunteerMattersVolunteer[]> {
  try {
    const data = await fetchVolunteerMattersData<any>('/volunteers');
    
    // Transform the API response to our expected format
    if (Array.isArray(data)) {
      return data.map((volunteer: any) => ({
        id: volunteer.id || volunteer.volunteerId,
        firstName: volunteer.firstName || volunteer.first_name,
        lastName: volunteer.lastName || volunteer.last_name,
        email: volunteer.email,
        phone: volunteer.phone,
        branchId: volunteer.branchId || volunteer.branch_id,
        branchName: volunteer.branchName || volunteer.branch_name,
        totalHours: volunteer.totalHours || volunteer.total_hours || 0,
        lastActivity: volunteer.lastActivity || volunteer.last_activity,
        status: volunteer.status || 'active'
      }));
    }
    
    return [];
  } catch (error) {
    console.error('Error fetching volunteers:', error);
    return [];
  }
}

// Get volunteers by branch (for staff)
export async function getVolunteersByBranch(branchId: string): Promise<VolunteerMattersVolunteer[]> {
  try {
    const allVolunteers = await getVolunteers();
    return allVolunteers.filter(volunteer => volunteer.branchId === branchId);
  } catch (error) {
    console.error('Error fetching volunteers by branch:', error);
    return [];
  }
}

// Get volunteer assignments/history
export async function getVolunteerHistory(volunteerId?: string): Promise<VolunteerMattersAssignment[]> {
  try {
    const data = await fetchVolunteerMattersData<any>('/volunteerHistory');
    
    console.log(`\n=== Volunteer History Data Processing ===`);
    console.log(`Raw data structure:`, typeof data);
    
    let assignments: VolunteerMattersAssignment[] = [];
    
    // Handle the paginated response format
    if (data && data.items && Array.isArray(data.items)) {
      console.log(`Found ${data.items.length} volunteer history items`);
      
      assignments = data.items.map((item: any) => {
        const assignment = item.assignment;
        const contact = assignment?.contact;
        
        return {
          id: assignment?.id || item.id,
          volunteerId: contact?.id || assignment?.volunteerId,
          projectId: assignment?.need?.project?.id,
          projectName: assignment?.need?.project?.name,
          branchId: assignment?.need?.project?.branch?.id,
          branchName: assignment?.need?.project?.branch?.name,
          date: item.volunteerDate,
          hours: item.creditedHours || 0,
          status: 'completed',
          description: assignment?.need?.name || 'Volunteer Assignment'
        };
      });
      
      console.log(`Processed ${assignments.length} assignments`);
      
      // Filter by volunteer ID if provided
      if (volunteerId) {
        console.log(`Filtering for volunteer ID: ${volunteerId}`);
        const beforeFilter = assignments.length;
        assignments = assignments.filter(assignment => 
          assignment.volunteerId && assignment.volunteerId.toString() === volunteerId.toString()
        );
        console.log(`Assignments before filter: ${beforeFilter}`);
        console.log(`Assignments after filter: ${assignments.length}`);
        
        // Log the matching assignments
        if (assignments.length > 0) {
          console.log('Matching assignments:');
          assignments.forEach((assignment, index) => {
            console.log(`  ${index + 1}. ${assignment.projectName} - ${assignment.hours} hours on ${assignment.date}`);
          });
        } else {
          console.log('No matching assignments found for this volunteer ID');
        }
      }
    } else if (Array.isArray(data)) {
      // Handle direct array format
      assignments = data.map((assignment: any) => ({
        id: assignment.id || assignment.assignmentId,
        volunteerId: assignment.volunteerId || assignment.volunteer_id,
        projectId: assignment.projectId || assignment.project_id,
        projectName: assignment.projectName || assignment.project_name,
        branchId: assignment.branchId || assignment.branch_id,
        branchName: assignment.branchName || assignment.branch_name,
        date: assignment.date || assignment.assignmentDate,
        hours: assignment.hours || assignment.hoursWorked || 0,
        status: assignment.status || 'completed',
        description: assignment.description
      }));
    }
    
    console.log(`=== End Volunteer History Processing ===\n`);
    return assignments;
  } catch (error) {
    console.error('Error fetching volunteer history:', error);
    return [];
  }
}

// Get projects
export async function getProjects(): Promise<VolunteerMattersProject[]> {
  try {
    const data = await fetchVolunteerMattersData<any>('/projects');
    
    if (Array.isArray(data)) {
      return data.map((project: any) => ({
        id: project.id || project.projectId,
        name: project.name || project.projectName,
        description: project.description,
        branchId: project.branchId || project.branch_id,
        branchName: project.branchName || project.branch_name,
        startDate: project.startDate || project.start_date,
        endDate: project.endDate || project.end_date,
        status: project.status || 'active',
        totalVolunteers: project.totalVolunteers || project.total_volunteers || 0,
        totalHours: project.totalHours || project.total_hours || 0
      }));
    }
    
    return [];
  } catch (error) {
    console.error('Error fetching projects:', error);
    return [];
  }
}

// Get branches
export async function getBranches(): Promise<VolunteerMattersBranch[]> {
  try {
    const data = await fetchVolunteerMattersData<any>('/branches');
    
    if (Array.isArray(data)) {
      return data.map((branch: any) => ({
        id: branch.id || branch.branchId,
        name: branch.name || branch.branchName,
        address: branch.address,
        phone: branch.phone,
        email: branch.email,
        totalVolunteers: branch.totalVolunteers || branch.total_volunteers || 0,
        totalHours: branch.totalHours || branch.total_hours || 0
      }));
    }
    
    return [];
  } catch (error) {
    console.error('Error fetching branches:', error);
    return [];
  }
}

// Calculate volunteer leaderboard for a branch
export async function getBranchLeaderboard(branchId: string): Promise<VolunteerLeaderboardEntry[]> {
  try {
    const volunteers = await getVolunteersByBranch(branchId);
    const assignments = await getVolunteerHistory();
    
    // Calculate total hours for each volunteer
    const volunteerHours = new Map<string, number>();
    
    assignments.forEach(assignment => {
      if (assignment.branchId === branchId) {
        const currentHours = volunteerHours.get(assignment.volunteerId) || 0;
        volunteerHours.set(assignment.volunteerId, currentHours + assignment.hours);
      }
    });
    
    // Create leaderboard entries
    const leaderboard: VolunteerLeaderboardEntry[] = volunteers.map(volunteer => {
      const totalHours = volunteerHours.get(volunteer.id) || volunteer.totalHours || 0;
      return {
        volunteerId: volunteer.id,
        firstName: volunteer.firstName,
        lastName: volunteer.lastName,
        totalHours,
        rank: 0 // Will be set after sorting
      };
    });
    
    // Sort by total hours (descending) and assign ranks
    leaderboard.sort((a, b) => b.totalHours - a.totalHours);
    leaderboard.forEach((entry, index) => {
      entry.rank = index + 1;
    });
    
    return leaderboard;
  } catch (error) {
    console.error('Error calculating branch leaderboard:', error);
    return [];
  }
}

// Calculate volunteer badges based on YMCA badge ladder
export function calculateVolunteerBadges(totalHours: number, assignments: VolunteerMattersAssignment[] = []): VolunteerBadge[] {
  // Calculate additional metrics for badge requirements
  const hasFirstShift = assignments.length > 0;
  const storyworldHours = assignments
    .filter(a => a.projectName?.toLowerCase().includes('storyworld'))
    .reduce((sum, a) => sum + a.hours, 0);
  const storyworldCount = new Set(
    assignments
      .filter(a => a.projectName?.toLowerCase().includes('storyworld'))
      .map(a => a.projectName)
  ).size;
  
  // Check if volunteer has been a mentor (simplified check for now)
  const hasMentorExperience = assignments.some(a => 
    a.projectName?.toLowerCase().includes('mentor') || 
    a.description?.toLowerCase().includes('mentor')
  );
  
  // Calculate survey average (placeholder - would need actual survey data)
  const surveyAverage = 4.2; // This would come from actual survey data
  
  // Log badge calculation details
  console.log('=== BADGE CALCULATION ===');
  console.log('Total Hours:', totalHours);
  console.log('Has First Shift:', hasFirstShift);
  console.log('Storyworld Hours:', storyworldHours);
  console.log('Storyworld Count:', storyworldCount);
  console.log('Has Mentor Experience:', hasMentorExperience);
  console.log('Survey Average:', surveyAverage);
  
  const badges: VolunteerBadge[] = [
    {
      id: 'pathfinder',
      name: 'Pathfinder',
      description: 'Completed your first shift',
      icon: '🛤️',
      hoursRequired: 0,
      earned: hasFirstShift,
      earnedDate: hasFirstShift ? new Date().toISOString() : undefined
    },
    {
      id: 'engager',
      name: 'Engager',
      description: '10+ volunteer hours',
      icon: '📚',
      hoursRequired: 10,
      earned: totalHours >= 10,
      earnedDate: totalHours >= 10 ? new Date().toISOString() : undefined
    },
    {
      id: 'connector',
      name: 'Connector',
      description: '25+ hours + avg survey ≥4/5',
      icon: '🤝',
      hoursRequired: 25,
      earned: totalHours >= 25 && surveyAverage >= 4,
      earnedDate: (totalHours >= 25 && surveyAverage >= 4) ? new Date().toISOString() : undefined
    },
    {
      id: 'activator',
      name: 'Activator',
      description: '50+ hours + mentor experience',
      icon: '⚡',
      hoursRequired: 50,
      earned: totalHours >= 50 && hasMentorExperience,
      earnedDate: (totalHours >= 50 && hasMentorExperience) ? new Date().toISOString() : undefined
    },
    {
      id: 'guide',
      name: 'Guide',
      description: '3+ Storyworlds in a quarter',
      icon: '🧭',
      hoursRequired: 0,
      earned: storyworldCount >= 3,
      earnedDate: storyworldCount >= 3 ? new Date().toISOString() : undefined
    },
    {
      id: 'passion-in-action',
      name: 'Passion-in-Action',
      description: '100+ volunteer hours',
      icon: '❤️',
      hoursRequired: 100,
      earned: totalHours >= 100,
      earnedDate: totalHours >= 100 ? new Date().toISOString() : undefined
    },
    {
      id: 'guiding-light',
      name: 'Guiding Light',
      description: '500+ volunteer hours',
      icon: '💡',
      hoursRequired: 500,
      earned: totalHours >= 500,
      earnedDate: totalHours >= 500 ? new Date().toISOString() : undefined
    }
  ];

  // Log earned badges
  const earnedBadges = badges.filter(badge => badge.earned);
  console.log('Earned Badges:', earnedBadges.map(b => b.name));
  console.log('=== END BADGE CALCULATION ===');
  
  return badges;
}

// Search for user in contacts by email
export async function searchUserByEmail(email: string): Promise<any | null> {
  try {
    console.log(`\n=== Contact Search for ${email} ===`);
    
    // Search through multiple pages to find the exact match
    let page = 0;
    const pageSize = 1000; // Maximum page size
    let totalPages = 1;
    
    while (page < totalPages) {
      console.log(`Searching page ${page + 1} of ${totalPages}...`);
      
      const data = await fetchVolunteerMattersData<any>(`/contacts?pageIndex=${page}&pageSize=${pageSize}`);
      
      if (page === 0) {
        totalPages = data.totalPages || 1;
        console.log(`Total pages to search: ${totalPages}`);
      }
      
      // Handle the paginated response format
      let searchResults;
      if (data && data.items && Array.isArray(data.items)) {
        searchResults = data.items;
        console.log(`Found ${data.items.length} contacts on page ${page + 1}`);
      } else {
        console.log(`No contacts found on page ${page + 1}`);
        page++;
        continue;
      }
      
      // Find exact email match on this page
      const exactMatch = searchResults.find(contact => 
        contact.email && contact.email.toLowerCase() === email.toLowerCase()
      );
      
      if (exactMatch) {
        console.log('Exact email match found:', {
          id: exactMatch.id || exactMatch.contactId,
          name: `${exactMatch.name?.first || exactMatch.firstName || ''} ${exactMatch.name?.last || exactMatch.lastName || ''}`.trim(),
          email: exactMatch.email,
          phone: exactMatch.mobile || exactMatch.phone || exactMatch.phoneNumber,
          branch: exactMatch.extended?.Primary_Branch || exactMatch.branchName || exactMatch.branch_name
        });
        console.log('=== End Contact Search ===\n');
        return exactMatch;
      }
      
      page++;
    }
    
    console.log('No exact email match found in any page');
    console.log('=== End Contact Search ===\n');
    return null;
  } catch (error) {
    console.error('Error searching user by email:', error);
    return null;
  }
}

// Get user profile by searching contacts and then getting volunteer history
export async function getUserProfileByEmail(email: string): Promise<VolunteerMattersVolunteer | null> {
  try {
    // First, search for the user in contacts
    const contactData = await searchUserByEmail(email);
    
    if (!contactData) {
      console.log('No contact found for email:', email);
      return null;
    }
    
    console.log('Contact found:', contactData);
    
    // Get the contact ID
    const contactId = contactData.id || contactData.contactId || contactData.volunteerId;
    
    if (!contactId) {
      console.log('No contact ID found in search results');
      return null;
    }
    
    // Get volunteer history for this contact
    const volunteerHistory = await getVolunteerHistory(contactId);
    
    // Log the volunteer history for debugging
    console.log(`\n=== Volunteer History for ${email} (Contact ID: ${contactId}) ===`);
    console.log(`Found ${volunteerHistory.length} volunteer assignments:`);
    
    if (volunteerHistory.length > 0) {
      volunteerHistory.forEach((assignment, index) => {
        console.log(`\nAssignment ${index + 1}:`);
        console.log(`  - Date: ${assignment.date}`);
        console.log(`  - Project: ${assignment.projectName || 'N/A'}`);
        console.log(`  - Branch: ${assignment.branchName || 'N/A'}`);
        console.log(`  - Hours: ${assignment.hours}`);
        console.log(`  - Status: ${assignment.status}`);
        console.log(`  - Description: ${assignment.description || 'N/A'}`);
      });
    } else {
      console.log('No volunteer assignments found for this contact.');
    }
    
    // Calculate total hours from history
    const totalHours = volunteerHistory.reduce((sum, assignment) => sum + assignment.hours, 0);
    console.log(`\nTotal calculated hours: ${totalHours}`);
    
    // Get the most recent activity
    const lastActivity = volunteerHistory.length > 0 
      ? volunteerHistory.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0].date
      : null;
    
    if (lastActivity) {
      console.log(`Most recent activity: ${lastActivity}`);
    }
    
    console.log('=== End Volunteer History ===\n');
    
    // Determine status based on recent activity (active if they've volunteered in the last 6 months)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    const hasRecentActivity = lastActivity && new Date(lastActivity) > sixMonthsAgo;
    const status = hasRecentActivity ? 'active' : 'inactive';
    
    // Transform the contact data to our volunteer format
    return {
      id: contactId,
      firstName: contactData.firstName || contactData.first_name || contactData.givenName,
      lastName: contactData.lastName || contactData.last_name || contactData.familyName,
      email: contactData.email || email,
      phone: contactData.phone || contactData.phoneNumber || contactData.mobile,
      branchId: contactData.branchId || contactData.branch_id || contactData.siteId,
      branchName: contactData.branchName || contactData.branch_name || contactData.siteName,
      totalHours,
      lastActivity,
      status
    };
  } catch (error) {
    console.error('Error fetching user profile by email:', error);
    return null;
  }
}

// Get multiple user profiles by email addresses
export async function getUserProfilesByEmails(emails: string[]): Promise<VolunteerMattersVolunteer[]> {
  try {
    const profiles = await Promise.all(
      emails.map(email => getUserProfileByEmail(email))
    );
    
    return profiles.filter(profile => profile !== null) as VolunteerMattersVolunteer[];
  } catch (error) {
    console.error('Error fetching user profiles by emails:', error);
    return [];
  }
}

// Enhanced function to get volunteer with profile data
export async function getVolunteerWithProfile(volunteerId: string, email?: string): Promise<VolunteerMattersVolunteer | null> {
  try {
    // First try to get from the general volunteers endpoint
    const volunteers = await getVolunteers();
    let volunteer = volunteers.find(v => v.id === volunteerId);
    
    // If not found and email is provided, try contacts API
    if (!volunteer && email) {
      volunteer = await getUserProfileByEmail(email);
    }
    
    return volunteer || null;
  } catch (error) {
    console.error('Error getting volunteer with profile:', error);
    return null;
  }
}

// Get branch volunteer statistics (for staff)
export async function getBranchVolunteerStats(branchId: string): Promise<BranchVolunteerStats> {
  try {
    const volunteers = await getVolunteersByBranch(branchId);
    const assignments = await getVolunteerHistory();
    const leaderboard = await getBranchLeaderboard(branchId);
    
    const branchAssignments = assignments.filter(assignment => assignment.branchId === branchId);
    const totalHours = branchAssignments.reduce((sum, assignment) => sum + assignment.hours, 0);
    const activeVolunteers = volunteers.filter(volunteer => volunteer.status === 'active').length;
    
    return {
      branchId,
      branchName: volunteers[0]?.branchName || 'Unknown Branch',
      totalVolunteers: volunteers.length,
      activeVolunteers,
      totalHours,
      averageHoursPerVolunteer: volunteers.length > 0 ? totalHours / volunteers.length : 0,
      topVolunteers: leaderboard.slice(0, 5) // Top 5 volunteers
    };
  } catch (error) {
    console.error('Error calculating branch stats:', error);
    return {
      branchId,
      branchName: 'Unknown Branch',
      totalVolunteers: 0,
      activeVolunteers: 0,
      totalHours: 0,
      averageHoursPerVolunteer: 0,
      topVolunteers: []
    };
  }
}
