'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/SimpleAuthContext';
import { UserRole } from '@/types/auth';

interface RegisterFormProps {
  onToggleMode: () => void;
}

export const RegisterForm: React.FC<RegisterFormProps> = ({ onToggleMode }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState<UserRole>('volunteer');
  const [branchId, setBranchId] = useState('');
  const [branchName, setBranchName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signUp } = useAuth();
  const router = useRouter();

  // Sample YMCA branches - in a real app, this would come from a database
  const ymcaBranches = [
    { id: 'downtown', name: 'Downtown YMCA' },
    { id: 'northside', name: 'Northside YMCA' },
    { id: 'southside', name: 'Southside YMCA' },
    { id: 'eastside', name: 'Eastside YMCA' },
    { id: 'westside', name: 'Westside YMCA' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      await signUp(email, password, displayName, role, branchId || undefined, branchName || undefined);
      // Redirect to dashboard after successful registration
      router.push('/dashboard');
    } catch (error: any) {
      setError(error.message || 'Failed to create account');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-ymca-gradient rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-2xl">Y</span>
          </div>
          <h2 className="text-3xl font-bold text-ymca-blue mb-2">
            Join Our Community
          </h2>
          <p className="text-ymca-gray">
            Create your YMCA Future of Data account
          </p>
        </div>

        {/* Form Card */}
        <div className="card-ymca">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label htmlFor="displayName" className="block text-sm font-semibold text-ymca-dark-gray mb-2">
                  Full Name
                </label>
                <input
                  id="displayName"
                  name="displayName"
                  type="text"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ymca-blue focus:border-ymca-blue transition-colors"
                  placeholder="Enter your full name"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-ymca-dark-gray mb-2">
                  Email Address
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ymca-blue focus:border-ymca-blue transition-colors"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div>
                <label htmlFor="role" className="block text-sm font-semibold text-ymca-dark-gray mb-2">
                  Select Your Role
                </label>
                <select
                  id="role"
                  name="role"
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ymca-blue focus:border-ymca-blue transition-colors bg-white"
                >
                  <option value="volunteer">🤝 Volunteer - Help make a difference in your community</option>
                  <option value="staff">👥 Staff - Manage programs and coordinate activities</option>
                </select>
              </div>

              {role === 'staff' && (
                <>
                  <div>
                    <label htmlFor="branchId" className="block text-sm font-semibold text-ymca-dark-gray mb-2">
                      Select Your YMCA Branch
                    </label>
                    <select
                      id="branchId"
                      name="branchId"
                      value={branchId}
                      onChange={(e) => {
                        const selectedBranch = ymcaBranches.find(branch => branch.id === e.target.value);
                        setBranchId(e.target.value);
                        setBranchName(selectedBranch?.name || '');
                      }}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ymca-blue focus:border-ymca-blue transition-colors bg-white"
                      required
                    >
                      <option value="">Choose your branch...</option>
                      {ymcaBranches.map((branch) => (
                        <option key={branch.id} value={branch.id}>
                          {branch.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              <div>
                <label htmlFor="password" className="block text-sm font-semibold text-ymca-dark-gray mb-2">
                  Password
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="new-password"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ymca-blue focus:border-ymca-blue transition-colors"
                  placeholder="Create a secure password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-semibold text-ymca-dark-gray mb-2">
                  Confirm Password
                </label>
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  autoComplete="new-password"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ymca-blue focus:border-ymca-blue transition-colors"
                  placeholder="Confirm your password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-ymca-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Creating account...' : 'Create Account'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-ymca-gray">
              Already have an account?{' '}
              <button
                onClick={onToggleMode}
                className="font-semibold text-ymca-blue hover:text-ymca-dark-blue transition-colors"
              >
                Sign in here
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
