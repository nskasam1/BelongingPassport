'use client';

import React from 'react';
import Link from 'next/link';
import { useAuth } from '@/contexts/SimpleAuthContext';

export const AdminDashboard: React.FC = () => {
  const { userProfile, signOut } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-ymca-red">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">Y</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-ymca-blue">
                  Admin Dashboard
                </h1>
                <p className="text-sm text-ymca-gray">System Administration</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <div className="text-right">
                <p className="text-sm text-ymca-gray">Welcome back,</p>
                <p className="font-semibold text-ymca-dark-gray">{userProfile?.displayName}</p>
              </div>
              <span className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-ymca-red text-white shadow-lg">
                ⚡ PRIMARY ADMIN
              </span>
              <button
                onClick={handleSignOut}
                className="btn-ymca-outline"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-ymca-blue mb-2">
            System Overview
          </h2>
          <p className="text-ymca-gray">
            Manage users, monitor system health, and oversee all YMCA Future of Data operations.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">👥</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Total Users</p>
                <p className="text-2xl font-bold text-ymca-blue">1,247</p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">👨‍💼</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Staff Members</p>
                <p className="text-2xl font-bold text-ymca-blue">89</p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">🤝</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Volunteers</p>
                <p className="text-2xl font-bold text-ymca-blue">1,158</p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">📊</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Active Projects</p>
                <p className="text-2xl font-bold text-ymca-blue">23</p>
              </div>
            </div>
          </div>
        </div>

        {/* Admin Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              User Management
            </h3>
            <div className="space-y-4">
              <Link href="/admin-portal" className="w-full btn-ymca-primary text-left block">
                👥 Manage All Users
              </Link>
              <button className="w-full btn-ymca-secondary text-left">
                ➕ Add New User
              </button>
              <button className="w-full btn-ymca-outline text-left">
                📋 User Reports
              </button>
            </div>
          </div>

          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              System Administration
            </h3>
            <div className="space-y-4">
              <button className="w-full btn-ymca-primary text-left">
                ⚙️ System Settings
              </button>
              <button className="w-full btn-ymca-secondary text-left">
                📈 Analytics Dashboard
              </button>
              <button className="w-full btn-ymca-outline text-left">
                🔒 Security Center
              </button>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mt-8">
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              Recent Activity
            </h3>
            <div className="space-y-4">
              <div className="flex items-center p-4 bg-ymca-light-gray rounded-lg">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white text-sm">✓</span>
                </div>
                <div>
                  <p className="font-medium text-ymca-dark-gray">New volunteer registered</p>
                  <p className="text-sm text-ymca-gray">Sarah Johnson joined 2 hours ago</p>
                </div>
              </div>
              <div className="flex items-center p-4 bg-ymca-light-gray rounded-lg">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white text-sm">📊</span>
                </div>
                <div>
                  <p className="font-medium text-ymca-dark-gray">Monthly report generated</p>
                  <p className="text-sm text-ymca-gray">Community impact metrics updated</p>
                </div>
              </div>
              <div className="flex items-center p-4 bg-ymca-light-gray rounded-lg">
                <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white text-sm">⚠️</span>
                </div>
                <div>
                  <p className="font-medium text-ymca-dark-gray">System maintenance scheduled</p>
                  <p className="text-sm text-ymca-gray">Scheduled for tonight at 2 AM</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
