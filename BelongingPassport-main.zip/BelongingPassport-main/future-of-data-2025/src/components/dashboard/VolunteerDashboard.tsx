'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/SimpleAuthContext';
import { 
  getBranchLeaderboard, 
  getVolunteerHistory, 
  calculateVolunteerBadges 
} from '@/lib/volunteerMattersApi';
import { 
  VolunteerLeaderboardEntry, 
  VolunteerMattersAssignment, 
  VolunteerBadge 
} from '@/types/volunteerMatters';

export const VolunteerDashboard: React.FC = () => {
  const { userProfile, signOut } = useAuth();
  const [leaderboard, setLeaderboard] = useState<VolunteerLeaderboardEntry[]>([]);
  const [myAssignments, setMyAssignments] = useState<VolunteerMattersAssignment[]>([]);
  const [myBadges, setMyBadges] = useState<VolunteerBadge[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [myTotalHours, setMyTotalHours] = useState(0);
  const [myRank, setMyRank] = useState(0);

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  // Load volunteer data when component mounts
  useEffect(() => {
    const loadVolunteerData = async () => {
      console.log('=== VOLUNTEER DASHBOARD LOADING ===');
      console.log('User Profile:', userProfile);
      
      if (!userProfile?.uid) {
        setError('No user profile found');
        setLoading(false);
        return;
      }

      // Use enhanced profile data if available
      const vmId = (userProfile as any).vmId;
      const vmTotalHours = (userProfile as any).vmTotalHours;
      const vmStatus = (userProfile as any).vmStatus;
      const vmLastActivity = (userProfile as any).vmLastActivity;
      
      console.log('Enhanced Profile Data:', {
        vmId,
        vmTotalHours,
        vmStatus,
        vmLastActivity,
        branchId: userProfile.branchId,
        branchName: userProfile.branchName
      });

      try {
        setLoading(true);
        
        // If we have VM data, use it directly instead of fetching
        if (vmTotalHours !== undefined && vmTotalHours !== null) {
          console.log('Using enhanced profile data for hours:', vmTotalHours);
          setMyTotalHours(vmTotalHours);
          
          // For badges, we still need assignments to check for Storyworld, mentor experience, etc.
          // Try to get assignments if we have a vmId
          let assignments: VolunteerMattersAssignment[] = [];
          if (vmId) {
            try {
              assignments = await getVolunteerHistory(vmId.toString());
              setMyAssignments(assignments);
              console.log('Fetched assignments for badge calculation:', assignments);
            } catch (error) {
              console.warn('Could not fetch assignments for badge calculation:', error);
            }
          }
          
          // Calculate badges with assignments data
          const badges = calculateVolunteerBadges(vmTotalHours, assignments);
          setMyBadges(badges);
          console.log('Calculated badges:', badges);
        } else {
          console.log('No VM data available, fetching from API...');
          // Fallback to API if no VM data
          const assignments = await getVolunteerHistory(userProfile.uid);
          setMyAssignments(assignments);
          
          const totalHours = assignments.reduce((sum, assignment) => sum + assignment.hours, 0);
          setMyTotalHours(totalHours);
          
          const badges = calculateVolunteerBadges(totalHours, assignments);
          setMyBadges(badges);
        }
        
        // Load leaderboard if we have branch info
        if (userProfile.branchId) {
          console.log('Loading leaderboard for branch:', userProfile.branchId);
          const leaderboardData = await getBranchLeaderboard(userProfile.branchId);
          setLeaderboard(leaderboardData);
          
          // Find my rank in the leaderboard
          const myEntry = leaderboardData.find(entry => entry.volunteerId === userProfile.uid);
          setMyRank(myEntry?.rank || 0);
          console.log('My rank in leaderboard:', myEntry?.rank || 0);
        } else {
          console.log('No branch ID available for leaderboard');
        }
        
        setError(null);
        console.log('=== VOLUNTEER DASHBOARD LOADED ===');
      } catch (err) {
        console.error('Error loading volunteer data:', err);
        setError('Failed to load volunteer data');
      } finally {
        setLoading(false);
      }
    };

    loadVolunteerData();
  }, [userProfile?.uid, userProfile?.branchId, (userProfile as any)?.vmId, (userProfile as any)?.vmTotalHours]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-ymca-red">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">Y</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-ymca-blue">
                  Volunteer Dashboard
                </h1>
                <p className="text-sm text-ymca-gray">Community Impact</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <div className="text-right">
                <p className="text-sm text-ymca-gray">Welcome back,</p>
                <p className="font-semibold text-ymca-dark-gray">{userProfile?.displayName}</p>
              </div>
              <span className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-green-500 text-white shadow-lg">
                🤝 VOLUNTEER
              </span>
              <button
                onClick={handleSignOut}
                className="btn-ymca-outline"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-ymca-blue mb-2">
            Make a Difference
          </h2>
          <p className="text-ymca-gray">
            Track your volunteer hours, discover new opportunities, and see the impact you're making in your community.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">⏰</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Total Hours</p>
                <p className="text-2xl font-bold text-ymca-blue">
                  {loading ? '...' : myTotalHours}
                </p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">🏆</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">My Rank</p>
                <p className="text-2xl font-bold text-ymca-blue">
                  {loading ? '...' : myRank > 0 ? `#${myRank}` : 'N/A'}
                </p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">🎯</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Activities</p>
                <p className="text-2xl font-bold text-ymca-blue">
                  {loading ? '...' : myAssignments.length}
                </p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">🏅</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Badges Earned</p>
                <p className="text-2xl font-bold text-ymca-blue">
                  {loading ? '...' : myBadges.filter(badge => badge.earned).length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Leaderboard and Badges */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Branch Leaderboard */}
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              Branch Leaderboard ({userProfile?.branchName || 'Your Branch'})
            </h3>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-ymca-blue"></div>
              </div>
            ) : error ? (
              <div className="text-center py-8">
                <p className="text-red-600 mb-4">{error}</p>
                <button 
                  onClick={() => window.location.reload()} 
                  className="btn-ymca-primary"
                >
                  Retry
                </button>
              </div>
            ) : leaderboard.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-ymca-gray">No leaderboard data available</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {leaderboard.slice(0, 10).map((volunteer, index) => (
                  <div 
                    key={volunteer.volunteerId} 
                    className={`flex items-center p-3 rounded-lg ${
                      volunteer.volunteerId === userProfile?.uid 
                        ? 'bg-ymca-blue text-white' 
                        : 'bg-ymca-light-gray'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                      volunteer.volunteerId === userProfile?.uid 
                        ? 'bg-white text-ymca-blue' 
                        : 'bg-ymca-gradient text-white'
                    }`}>
                      <span className="font-bold text-sm">#{volunteer.rank}</span>
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${
                        volunteer.volunteerId === userProfile?.uid 
                          ? 'text-white' 
                          : 'text-ymca-dark-gray'
                      }`}>
                        {volunteer.firstName} {volunteer.lastName}
                        {volunteer.volunteerId === userProfile?.uid && ' (You)'}
                      </p>
                      <p className={`text-sm ${
                        volunteer.volunteerId === userProfile?.uid 
                          ? 'text-blue-100' 
                          : 'text-ymca-gray'
                      }`}>
                        {volunteer.totalHours} total hours
                      </p>
                    </div>
                    <div className="text-right">
                      {index === 0 && <span className="text-yellow-500 text-lg">🏆</span>}
                      {index === 1 && <span className="text-gray-400 text-lg">🥈</span>}
                      {index === 2 && <span className="text-orange-500 text-lg">🥉</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* My Badges */}
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              My Badges
            </h3>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-ymca-blue"></div>
              </div>
            ) : myBadges.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-ymca-gray">No badges available</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {myBadges.map((badge) => (
                  <div 
                    key={badge.id} 
                    className={`p-4 rounded-lg text-center ${
                      badge.earned 
                        ? 'bg-gradient-to-br from-yellow-100 to-yellow-200 border-2 border-yellow-400' 
                        : 'bg-gray-100 border-2 border-gray-300'
                    }`}
                  >
                    <div className="text-3xl mb-2">{badge.icon}</div>
                    <h4 className={`font-bold text-sm mb-1 ${
                      badge.earned ? 'text-yellow-800' : 'text-gray-500'
                    }`}>
                      {badge.name}
                    </h4>
                    <p className={`text-xs ${
                      badge.earned ? 'text-yellow-700' : 'text-gray-400'
                    }`}>
                      {badge.hoursRequired}h required
                    </p>
                    {badge.earned && (
                      <p className="text-xs text-green-600 font-medium mt-1">
                        ✓ Earned!
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Upcoming Opportunities */}
        <div className="mt-8">
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              Upcoming Opportunities
            </h3>
            <div className="space-y-4">
              <div className="flex items-center p-4 bg-ymca-light-gray rounded-lg">
                <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center mr-4">
                  <span className="text-white font-bold">📊</span>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-ymca-dark-gray">Data Science Workshop</p>
                  <p className="text-sm text-ymca-gray">Tomorrow at 2:00 PM • Learn data analysis techniques</p>
                </div>
                <button className="btn-ymca-primary text-sm px-4 py-2">
                  Join
                </button>
              </div>
              <div className="flex items-center p-4 bg-ymca-light-gray rounded-lg">
                <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mr-4">
                  <span className="text-white font-bold">🎯</span>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-ymca-dark-gray">Community Impact Assessment</p>
                  <p className="text-sm text-ymca-gray">Friday at 10:00 AM • Help measure our impact</p>
                </div>
                <button className="btn-ymca-primary text-sm px-4 py-2">
                  Join
                </button>
              </div>
              <div className="flex items-center p-4 bg-ymca-light-gray rounded-lg">
                <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mr-4">
                  <span className="text-white font-bold">🤝</span>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-ymca-dark-gray">Volunteer Appreciation Event</p>
                  <p className="text-sm text-ymca-gray">Next Saturday at 6:00 PM • Celebrate our community</p>
                </div>
                <button className="btn-ymca-primary text-sm px-4 py-2">
                  Join
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
