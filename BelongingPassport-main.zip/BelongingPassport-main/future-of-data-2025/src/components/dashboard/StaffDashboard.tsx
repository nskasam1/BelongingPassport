'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/SimpleAuthContext';
import { getBranchVolunteerStats, getVolunteersByBranch } from '@/lib/volunteerMattersApi';
import { BranchVolunteerStats, VolunteerMattersVolunteer } from '@/types/volunteerMatters';

export const StaffDashboard: React.FC = () => {
  const { userProfile, signOut } = useAuth();
  const [branchStats, setBranchStats] = useState<BranchVolunteerStats | null>(null);
  const [volunteers, setVolunteers] = useState<VolunteerMattersVolunteer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  // Load branch data when component mounts
  useEffect(() => {
    const loadBranchData = async () => {
      console.log('=== STAFF DASHBOARD LOADING ===');
      console.log('User Profile:', userProfile);
      console.log('Branch ID:', userProfile?.branchId);
      console.log('Branch Name:', userProfile?.branchName);
      
      if (!userProfile?.branchId) {
        setError('No branch assigned to your account');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        console.log('Fetching branch stats and volunteers...');
        const [stats, branchVolunteers] = await Promise.all([
          getBranchVolunteerStats(userProfile.branchId),
          getVolunteersByBranch(userProfile.branchId)
        ]);
        
        console.log('Branch Stats:', stats);
        console.log('Branch Volunteers:', branchVolunteers);
        
        setBranchStats(stats);
        setVolunteers(branchVolunteers);
        setError(null);
        console.log('=== STAFF DASHBOARD LOADED ===');
      } catch (err) {
        console.error('Error loading branch data:', err);
        setError('Failed to load volunteer data');
      } finally {
        setLoading(false);
      }
    };

    loadBranchData();
  }, [userProfile?.branchId]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg border-b-4 border-ymca-red">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">Y</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-ymca-blue">
                  Staff Dashboard
                </h1>
                <p className="text-sm text-ymca-gray">Program Management</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <div className="text-right">
                <p className="text-sm text-ymca-gray">Welcome back,</p>
                <p className="font-semibold text-ymca-dark-gray">{userProfile?.displayName}</p>
              </div>
              <span className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-ymca-blue text-white shadow-lg">
                👥 STAFF
              </span>
              <button
                onClick={handleSignOut}
                className="btn-ymca-outline"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-ymca-blue mb-2">
            Program Management
          </h2>
          <p className="text-ymca-gray">
            Coordinate volunteers, manage events, and track community impact for YMCA Future of Data programs.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">🤝</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Total Volunteers</p>
                <p className="text-2xl font-bold text-ymca-blue">
                  {loading ? '...' : branchStats?.totalVolunteers || 0}
                </p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">⭐</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Active Volunteers</p>
                <p className="text-2xl font-bold text-ymca-blue">
                  {loading ? '...' : branchStats?.activeVolunteers || 0}
                </p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">⏰</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Total Hours</p>
                <p className="text-2xl font-bold text-ymca-blue">
                  {loading ? '...' : branchStats?.totalHours || 0}
                </p>
              </div>
            </div>
          </div>

          <div className="card-ymca">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-ymca-gradient rounded-lg flex items-center justify-center mr-4">
                <span className="text-white font-bold text-lg">📊</span>
              </div>
              <div>
                <p className="text-sm font-medium text-ymca-gray">Avg Hours/Volunteer</p>
                <p className="text-2xl font-bold text-ymca-blue">
                  {loading ? '...' : Math.round(branchStats?.averageHoursPerVolunteer || 0)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              Volunteer Management
            </h3>
            <div className="space-y-4">
              <button className="w-full btn-ymca-primary text-left">
                👥 Manage Volunteers
              </button>
              <button className="w-full btn-ymca-secondary text-left">
                ➕ Add New Volunteer
              </button>
              <button className="w-full btn-ymca-outline text-left">
                📋 Volunteer Reports
              </button>
            </div>
          </div>

          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              Event Coordination
            </h3>
            <div className="space-y-4">
              <button className="w-full btn-ymca-primary text-left">
                📅 Create Event
              </button>
              <button className="w-full btn-ymca-secondary text-left">
                📊 Event Analytics
              </button>
              <button className="w-full btn-ymca-outline text-left">
                📝 Event Reports
              </button>
            </div>
          </div>
        </div>

        {/* Branch Volunteers and Top Performers */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Branch Volunteers */}
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              Branch Volunteers ({userProfile?.branchName || 'Your Branch'})
            </h3>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-ymca-blue"></div>
              </div>
            ) : error ? (
              <div className="text-center py-8">
                <p className="text-red-600 mb-4">{error}</p>
                <button 
                  onClick={() => window.location.reload()} 
                  className="btn-ymca-primary"
                >
                  Retry
                </button>
              </div>
            ) : volunteers.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-ymca-gray">No volunteers found in your branch</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {volunteers.map((volunteer) => (
                  <div key={volunteer.id} className="flex items-center p-3 bg-ymca-light-gray rounded-lg">
                    <div className="w-10 h-10 bg-ymca-gradient rounded-full flex items-center justify-center mr-3">
                      <span className="text-white font-bold text-sm">
                        {volunteer.firstName[0]}{volunteer.lastName[0]}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-ymca-dark-gray">
                        {volunteer.firstName} {volunteer.lastName}
                      </p>
                      <p className="text-sm text-ymca-gray">{volunteer.email}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-ymca-blue">{volunteer.totalHours}h</p>
                      <p className="text-xs text-ymca-gray capitalize">{volunteer.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Top Performers */}
          <div className="card-ymca">
            <h3 className="text-xl font-bold text-ymca-blue mb-6">
              Top Performers
            </h3>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-ymca-blue"></div>
              </div>
            ) : branchStats?.topVolunteers.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-ymca-gray">No volunteer data available</p>
              </div>
            ) : (
              <div className="space-y-3">
                {branchStats?.topVolunteers.map((volunteer, index) => (
                  <div key={volunteer.volunteerId} className="flex items-center p-3 bg-ymca-light-gray rounded-lg">
                    <div className="w-8 h-8 bg-ymca-gradient rounded-full flex items-center justify-center mr-3">
                      <span className="text-white font-bold text-sm">#{volunteer.rank}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-ymca-dark-gray">
                        {volunteer.firstName} {volunteer.lastName}
                      </p>
                      <p className="text-sm text-ymca-gray">{volunteer.totalHours} total hours</p>
                    </div>
                    <div className="text-right">
                      {index === 0 && <span className="text-yellow-500 text-lg">🏆</span>}
                      {index === 1 && <span className="text-gray-400 text-lg">🥈</span>}
                      {index === 2 && <span className="text-orange-500 text-lg">🥉</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
