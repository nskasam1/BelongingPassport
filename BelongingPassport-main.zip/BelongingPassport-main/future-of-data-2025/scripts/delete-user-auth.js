// Script to delete a user from Firebase Authentication
// Run with: node scripts/delete-user-auth.js

const admin = require('firebase-admin');

// Initialize Firebase Admin SDK
// You'll need to download your service account key from Firebase Console
// Go to Project Settings → Service Accounts → Generate New Private Key
const serviceAccount = require('./path-to-your-service-account-key.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://your-project-id.firebaseio.com'
});

async function deleteUserByEmail(email) {
  try {
    console.log(`Looking for user with email: ${email}`);
    
    // Get user by email
    const userRecord = await admin.auth().getUserByEmail(email);
    console.log('User found:', userRecord.uid);
    
    // Delete the user
    await admin.auth().deleteUser(userRecord.uid);
    console.log('✅ User successfully deleted from Firebase Authentication');
    
  } catch (error) {
    if (error.code === 'auth/user-not-found') {
      console.log('❌ User not found in Firebase Authentication');
    } else {
      console.error('❌ Error deleting user:', error.message);
    }
  }
}

// Get email from command line argument
const email = process.argv[2];

if (!email) {
  console.log('Usage: node delete-user-auth.js user@example.com');
  process.exit(1);
}

deleteUserByEmail(email);
