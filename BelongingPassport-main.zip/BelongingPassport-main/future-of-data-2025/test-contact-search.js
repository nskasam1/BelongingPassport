// Test script for contact search functionality
// Run with: node test-contact-search.js

const API_BASE_URL = 'http://localhost:3000/api';

async function testContactSearch() {
  console.log('🧪 Testing Contact Search API...\n');

  // Test email - replace with a real email from your VolunteerMatters system
  const testEmail = 'test@example.com';

  try {
    // Test 1: Search for contact
    console.log('1️⃣ Testing contact search...');
    const searchResponse = await fetch(`${API_BASE_URL}/data?endpoint=/contacts/_search&email=${encodeURIComponent(testEmail)}`);
    const searchResult = await searchResponse.json();
    
    if (searchResult.success) {
      console.log('✅ Contact search successful!');
      console.log('   Data received:', typeof searchResult.data);
      console.log('   Sample data:', JSON.stringify(searchResult.data, null, 2).substring(0, 200) + '...');
    } else {
      console.log('❌ Contact search failed:', searchResult.error);
    }

    console.log('\n2️⃣ Testing full user lookup...');
    
    // Test 2: Full user lookup with profile
    const lookupResponse = await fetch(`${API_BASE_URL}/lookup-user?email=${encodeURIComponent(testEmail)}`);
    const lookupResult = await lookupResponse.json();
    
    if (lookupResult.success) {
      console.log('✅ User lookup successful!');
      console.log('   Contact found:', lookupResult.data.contact ? 'Yes' : 'No');
      console.log('   Profile found:', lookupResult.data.profile ? 'Yes' : 'No');
      
      if (lookupResult.data.profile) {
        console.log('   Name:', `${lookupResult.data.profile.firstName} ${lookupResult.data.profile.lastName}`);
        console.log('   Total Hours:', lookupResult.data.profile.totalHours);
        console.log('   Status:', lookupResult.data.profile.status);
      }
    } else {
      console.log('❌ User lookup failed:', lookupResult.error);
    }

    console.log('\n3️⃣ Testing volunteer history endpoint...');
    
    // Test 3: Test volunteer history endpoint directly
    const historyResponse = await fetch(`${API_BASE_URL}/data?endpoint=/volunteerHistory`);
    const historyResult = await historyResponse.json();
    
    if (historyResult.success) {
      console.log('✅ Volunteer history endpoint working!');
      console.log('   Records found:', Array.isArray(historyResult.data) ? historyResult.data.length : 'Unknown');
    } else {
      console.log('❌ Volunteer history endpoint failed:', historyResult.error);
    }

  } catch (error) {
    console.error('❌ Test failed with error:', error.message);
  }
}

// Run the test
testContactSearch();
